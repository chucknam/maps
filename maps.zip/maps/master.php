<!DOCTYPE html>
<html>
  <head>
    <title>Get Current Position</title>
    <meta name="viewport" content="initial-scale=1.0">
    <meta charset="utf-8">
	<link rel="stylesheet" href="routing/dist/leaflet-routing-machine.css" media="screen"/>
	<link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css"
   integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA=="
   crossorigin=""/>
    <!-- Make sure you put this AFTER Leaflet's CSS -->
	<script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js"
   integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA=="
   crossorigin=""></script>
   <script src="routing/dist/leaflet-routing-machine.js" type="text/javascript"></script>
   <script src="routing/examples/Control.Geocoder.js" type="text/javascript"></script>
   <script src="routing/examples/config.js" type="text/javascript"></script>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
  <body>
    <div id="map" style="height: 500px; width:800px"></div>
  </body>
  <script>
		navigator.geolocation.getCurrentPosition(function(location){
		let lat	= location.coords.latitude;
		let lng	= location.coords.longitude;
		// alert(lat+" "+lng); //Debug
		
		/*
		var latlng	= new L.LatLng(lat,lng);
		var mymap	= L.map('map').setView(latlng, 15);
		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1Ijoicml6a2k1NDExIiwiYSI6ImNqbTA3ZnF5ZTBxdTYzdnJ2dnZkYXlwMGcifQ.1_pzE-figSaW5mco_6gDjQ', {
			attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
			maxZoom: 18,
			id: 'mapbox.streets',
			accessToken: 'your.mapbox.access.token'
	
		}).addTo(mymap);
		
		L.marker(latlng).addTo(mymap);
		
		var popup = L.popup();
		*/
	  });
	  /*
	var mymap	= L.map('map').setView([-7.308928, 112.734617], 15);
	<?php
		//Koneksi
		session_start(); 
		$con=mysqli_connect("localhost","root","","sahaba15_map");
		// Check connection
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		
		//Query
		$querys	=mysqli_query($con,"SELECT * FROM koordinat");
		//Tampilkan
		while ($koor = mysqli_fetch_array($querys)){
	
	?>
		var marker	= L.marker([<?php echo $koor['longi'] ?>, <?php echo $koor['lati'] ?>]).addTo(mymap)
				marker.bindPopup("<?php echo $koor['nama'] ?>");
				
				// use defaults
var line = L.polyline([<?php echo $koor['longi'] ?>, <?php echo $koor['lati'] ?>]);
// override defaults
var line = L.polyline([<?php echo $koor['longi'] ?>, <?php echo $koor['lati'] ?>], {
	distanceMarkers: { showAll: 11, offset: 1600, cssClass: 'some-other-class', iconSize: [16, 16] }
});
	<?php
		}
	?>


		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1Ijoicml6a2k1NDExIiwiYSI6ImNqbTA3ZnF5ZTBxdTYzdnJ2dnZkYXlwMGcifQ.1_pzE-figSaW5mco_6gDjQ', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox.streets',
    accessToken: 'your.mapbox.access.token'
	
}).addTo(mymap);
var line = L.polyline([<?php echo $koor['longi'] ?>, <?php echo $koor['lati'] ?>]);
		map.fitBounds(line.getBounds());
		map.addLayer(line);
		*/
	</script>
	
</html>