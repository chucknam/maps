<?php 

include 'koneksi.php';

$nis 			= $_POST['nis'];
$id_kamar		= $_POST['id_kamar'];
$nama_santri 	= $_POST['nama_santri'];
$jk 			= $_POST['jk'];
$alamat   		= $_POST['alamat'];

$query = mysqli_query($koneksi,"INSERT INTO santri (nis,nama_santri,id_kamar,jk,alamat) values ('$nis','$nama_santri','$id_kamar','$jk','$alamat') ");

if($query){
	echo "<script>alert('data berhasil dimasukkan');</script>";
	header("Location: index.php");
}else{	
}

?>