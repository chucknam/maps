<!DOCTYPE html>
<html>
<head>
	
	<title>Map Pemetaan Kamar Pondok Putra Amanatul Ummah</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="shortcut icon" type="image/x-icon" href="docs/images/favicon.ico" />

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" integrity="sha512-puBpdR0798OZvTTbP4A8Ix/l+A4dHDD0DGqYW6RQ+9jxkRFclaxxQb/SJAWZfWAkuyeQUytO7+7N4QKrDh+drA==" crossorigin=""/>
    <link rel="stylesheet" href="routing/dist/leaflet-routing-machine.css" />
    <link rel="stylesheet" href="routing/examples/index.css" />
    <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js" integrity="sha512-nMMmRyTVoLYqjP9hrbed9S+FzjZHW5gY1TWCHA5ckwXZBadntCNs8kEqAWdrb9O7rxbCaA4lKTIWjDXZxflOcA==" crossorigin=""></script>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php include 'koneksi.php'; ?>

<div id="mapid" style="width: 100%; height: 600px;"></div>
<a class="link" href="login.php" >
	<button>
	login
</button> 
</a>
<script>  
    var mymap = L.map('mapid').setView([-7.33482,112.73219], 21)
        L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://mapbox.com">Mapbox</a>',
            maxZoom: 35,
            id: 'mapbox.streets',
            accessToken: 'pk.eyJ1IjoiYmJyb29rMTU0IiwiYSI6ImNpcXN3dnJrdDAwMGNmd250bjhvZXpnbWsifQ.Nf9Zkfchos577IanoKMoYQ'
        }).addTo(mymap);
  
	  
	<?php
		$query = mysqli_query($koneksi,"SELECT * FROM kamar");
		while ($d_query = mysqli_fetch_array($query)) {
		
	?>

	L.polygon([
		[<?php echo $d_query['koordinat1'] ?>],
		[<?php echo $d_query['koordinat2'] ?>],
		[<?php echo $d_query['koordinat3'] ?>],
		[<?php echo $d_query['koordinat4'] ?>]
	],{
		<?php
			$id_kamar = $d_query['id_kamar'];
			$q_jum = mysqli_query($koneksi,"SELECT count(*) as jum_santri from santri where id_kamar = $id_kamar");
			$d_jum = mysqli_fetch_array($q_jum);
			$jumlah_santri = $d_jum['jum_santri'];
			if ($jumlah_santri > 2) {
				echo "
				color: '#110e0e', //batas
				fillColor: 'red',  //warna tengah
				fillOpacity: 1";   //transparansi
			} else if ($jumlah_santri > 1 and ($jumlah_santri <= 2)) {
				echo "
				color: '#110e0e',
				fillColor: 'blue',
				fillOpacity: 1";
			}else if ($jumlah_santri > 0 and ($jumlah_santri <= 1)) {
				echo "
				color: '#110e0e',
				fillColor: '#67fc11',
				fillOpacity: 1";
			}
		?>
		
	}).addTo(mymap).bindPopup("<?php echo $d_query['nama_kamar'] ?>");

<?php } ?>


	var popup = L.popup();

	function onMapClick(e) {
		popup
			.setLatLng(e.latlng)
			.setContent("You clicked the map at " + e.latlng.toString())
			.openOn(mymap);
	}

	mymap.on('click', onMapClick);
    
</script>
 <script src="https://unpkg.com/leaflet@1.0.0-rc.3/dist/leaflet.js"></script>
    <script src="routing/dist/leaflet-routing-machine.js"></script>
    <script src="routing/examples/Control.Geocoder.js"></script>
    <script src="routing/examples/config.js"></script>
    
</body>
</html>
